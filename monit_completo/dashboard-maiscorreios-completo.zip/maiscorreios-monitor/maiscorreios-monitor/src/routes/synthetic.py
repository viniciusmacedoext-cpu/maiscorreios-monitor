from flask import Blueprint, jsonify, request
from src.models.synthetic_monitor import db, SyntheticTest, SyntheticResult, SyntheticStep
from src.synthetic_engine import MaisCorreiosSyntheticEngine
from datetime import datetime, timedelta
import json
import threading
import time

synthetic_bp = Blueprint('synthetic', __name__)

def execute_test_async(test_id):
    """Executa teste sintético de forma assíncrona"""
    try:
        # Busca o teste
        test = SyntheticTest.query.get(test_id)
        if not test:
            return
        
        # Carrega configuração
        config = json.loads(test.config_json) if test.config_json else {}
        
        # Executa o teste
        engine = MaisCorreiosSyntheticEngine()
        start_time = time.time()
        
        result = engine.execute_full_test(config)
        
        duration = time.time() - start_time
        
        # Salva resultado no banco
        with db.session.begin():
            synthetic_result = SyntheticResult(
                test_id=test.id,
                status=result['status'],
                duration_seconds=duration,
                steps_completed=result.get('steps_completed', 0),
                total_steps=result.get('total_steps', 0),
                success_rate=result.get('success_rate', 0.0),
                error_message=result.get('error')
            )
            
            db.session.add(synthetic_result)
            db.session.flush()  # Para obter o ID
            
            # Salva os passos
            for step_data in result.get('steps_results', []):
                step = SyntheticStep(
                    result_id=synthetic_result.id,
                    step_name=step_data['step_name'],
                    step_order=step_data['step_order'],
                    status=step_data['status'],
                    duration_seconds=step_data['duration'],
                    error_message=step_data.get('message'),
                    screenshot_path=step_data.get('screenshot')
                )
                db.session.add(step)
            
            db.session.commit()
            
        print(f"✅ Teste sintético {test.test_name} executado com sucesso")
        
    except Exception as e:
        print(f"❌ Erro na execução do teste sintético: {e}")
        
        # Salva resultado de erro
        try:
            with db.session.begin():
                synthetic_result = SyntheticResult(
                    test_id=test_id,
                    status='failed',
                    duration_seconds=time.time() - start_time if 'start_time' in locals() else 0,
                    steps_completed=0,
                    total_steps=6,
                    success_rate=0.0,
                    error_message=str(e)
                )
                db.session.add(synthetic_result)
                db.session.commit()
        except:
            pass

@synthetic_bp.route('/synthetic-tests', methods=['GET'])
def get_synthetic_tests():
    """Lista todos os testes sintéticos"""
    try:
        tests = SyntheticTest.query.filter_by(is_active=True).all()
        return jsonify({
            'success': True,
            'tests': [test.to_dict() for test in tests]
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@synthetic_bp.route('/synthetic-tests', methods=['POST'])
def create_synthetic_test():
    """Cria um novo teste sintético"""
    try:
        data = request.get_json()
        
        if not data or not data.get('test_name') or not data.get('site_url'):
            return jsonify({
                'success': False,
                'error': 'Nome do teste e URL do site são obrigatórios'
            }), 400
        
        # Cria novo teste
        new_test = SyntheticTest(
            test_name=data['test_name'],
            test_type=data.get('test_type', 'purchase_flow'),
            site_url=data['site_url'],
            config_json=json.dumps(data.get('config', {}))
        )
        
        db.session.add(new_test)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'test': new_test.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@synthetic_bp.route('/synthetic-tests/<int:test_id>/execute', methods=['POST'])
def execute_synthetic_test(test_id):
    """Executa um teste sintético"""
    try:
        test = SyntheticTest.query.get_or_404(test_id)
        
        # Executa o teste em thread separada para não bloquear a resposta
        thread = threading.Thread(target=execute_test_async, args=(test_id,))
        thread.daemon = True
        thread.start()
        
        return jsonify({
            'success': True,
            'message': 'Teste sintético iniciado com sucesso'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@synthetic_bp.route('/synthetic-tests/<int:test_id>/results', methods=['GET'])
def get_test_results(test_id):
    """Obtém resultados de um teste sintético"""
    try:
        limit = request.args.get('limit', 10, type=int)
        
        results = SyntheticResult.query.filter_by(test_id=test_id)\
                                     .order_by(SyntheticResult.executed_at.desc())\
                                     .limit(limit).all()
        
        return jsonify({
            'success': True,
            'results': [result.to_dict() for result in results]
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@synthetic_bp.route('/synthetic-results/<int:result_id>/steps', methods=['GET'])
def get_result_steps(result_id):
    """Obtém passos de um resultado específico"""
    try:
        steps = SyntheticStep.query.filter_by(result_id=result_id)\
                                  .order_by(SyntheticStep.step_order.asc()).all()
        
        return jsonify({
            'success': True,
            'steps': [step.to_dict() for step in steps]
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@synthetic_bp.route('/synthetic-stats', methods=['GET'])
def get_synthetic_stats():
    """Obtém estatísticas dos testes sintéticos"""
    try:
        total_tests = SyntheticTest.query.filter_by(is_active=True).count()
        
        # Resultados das últimas 24h
        yesterday = datetime.now() - timedelta(hours=24)
        recent_results = SyntheticResult.query.filter(SyntheticResult.executed_at >= yesterday).all()
        
        total_executions = len(recent_results)
        successful_executions = len([r for r in recent_results if r.status == 'success'])
        
        success_rate = (successful_executions / total_executions * 100) if total_executions > 0 else 0
        
        # Duração média
        durations = [r.duration_seconds for r in recent_results if r.duration_seconds]
        avg_duration = sum(durations) / len(durations) if durations else 0
        
        return jsonify({
            'success': True,
            'stats': {
                'total_tests': total_tests,
                'total_executions': total_executions,
                'successful_executions': successful_executions,
                'success_rate': round(success_rate, 1),
                'avg_duration': round(avg_duration, 1)
            }
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@synthetic_bp.route('/synthetic-tests/<int:test_id>', methods=['DELETE'])
def delete_synthetic_test(test_id):
    """Remove um teste sintético"""
    try:
        test = SyntheticTest.query.get_or_404(test_id)
        test.is_active = False
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Teste sintético removido'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@synthetic_bp.route('/synthetic-performance', methods=['GET'])
def get_synthetic_performance():
    """Obtém dados de performance dos testes sintéticos para gráficos"""
    try:
        hours = request.args.get('hours', 24, type=int)
        since = datetime.now() - timedelta(hours=hours)
        
        results = SyntheticResult.query.filter(SyntheticResult.executed_at >= since)\
                                     .order_by(SyntheticResult.executed_at.asc()).all()
        
        performance_data = []
        for result in results:
            performance_data.append({
                'timestamp': result.executed_at.isoformat(),
                'success_rate': result.success_rate,
                'duration': result.duration_seconds,
                'status': result.status,
                'test_name': result.synthetic_test.test_name
            })
        
        return jsonify({
            'success': True,
            'performance_data': performance_data
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

