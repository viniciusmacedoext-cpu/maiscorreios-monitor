import time
import os
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.common.exceptions import TimeoutException, NoSuchElementException, WebDriverException
from webdriver_manager.chrome import ChromeDriverManager

class MaisCorreiosSyntheticEngine:
    def __init__(self):
        self.driver = None
        self.wait = None
        self.screenshots_dir = os.path.join(os.path.dirname(__file__), 'screenshots')
        os.makedirs(self.screenshots_dir, exist_ok=True)
        
    def setup_driver(self):
        """Configura o driver do Chrome"""
        try:
            chrome_options = Options()
            chrome_options.add_argument('--headless')
            chrome_options.add_argument('--no-sandbox')
            chrome_options.add_argument('--disable-dev-shm-usage')
            chrome_options.add_argument('--disable-gpu')
            chrome_options.add_argument('--window-size=1920,1080')
            chrome_options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36')
            
            # Instalar ChromeDriver automaticamente
            service = Service(ChromeDriverManager().install())
            
            self.driver = webdriver.Chrome(service=service, options=chrome_options)
            self.wait = WebDriverWait(self.driver, 30)
            
            return True
        except Exception as e:
            print(f"Erro ao configurar driver: {e}")
            return False
    
    def take_screenshot(self, step_name):
        """Tira screenshot do estado atual"""
        try:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"{step_name}_{timestamp}.png"
            filepath = os.path.join(self.screenshots_dir, filename)
            self.driver.save_screenshot(filepath)
            return filepath
        except Exception as e:
            print(f"Erro ao tirar screenshot: {e}")
            return None
    
    def step_access_site(self, site_url):
        """Passo 1: Acessa o site principal"""
        try:
            start_time = time.time()
            self.driver.get(site_url)
            
            # Aguarda a página carregar
            self.wait.until(EC.presence_of_element_located((By.TAG_NAME, "body")))
            
            duration = time.time() - start_time
            screenshot = self.take_screenshot("01_access_site")
            
            return {
                'status': 'success',
                'duration': duration,
                'screenshot': screenshot,
                'message': f'Site acessado com sucesso em {duration:.2f}s'
            }
        except TimeoutException:
            return {
                'status': 'failed',
                'duration': time.time() - start_time,
                'screenshot': self.take_screenshot("01_access_site_error"),
                'message': 'Timeout ao acessar o site'
            }
        except Exception as e:
            return {
                'status': 'failed',
                'duration': time.time() - start_time,
                'screenshot': self.take_screenshot("01_access_site_error"),
                'message': f'Erro ao acessar site: {str(e)}'
            }
    
    def step_login_google(self, email, password):
        """Passo 2: Realiza login com Google"""
        try:
            start_time = time.time()
            
            # Procura por botão de login ou área de login
            login_selectors = [
                "//a[contains(text(), 'Login')]",
                "//a[contains(text(), 'Entrar')]",
                "//button[contains(text(), 'Login')]",
                "//button[contains(text(), 'Entrar')]",
                ".login-button",
                "#login-button",
                "[data-testid='login']"
            ]
            
            login_element = None
            for selector in login_selectors:
                try:
                    if selector.startswith("//"):
                        login_element = self.wait.until(EC.element_to_be_clickable((By.XPATH, selector)))
                    else:
                        login_element = self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, selector)))
                    break
                except TimeoutException:
                    continue
            
            if not login_element:
                # Tenta procurar por elementos que contenham "google" no texto ou classe
                google_selectors = [
                    "//a[contains(text(), 'Google')]",
                    "//button[contains(text(), 'Google')]",
                    "//a[contains(@class, 'google')]",
                    "//button[contains(@class, 'google')]"
                ]
                
                for selector in google_selectors:
                    try:
                        login_element = self.wait.until(EC.element_to_be_clickable((By.XPATH, selector)))
                        break
                    except TimeoutException:
                        continue
            
            if login_element:
                login_element.click()
                time.sleep(3)  # Aguarda redirecionamento
                
                # Se redirecionou para Google, preenche credenciais
                if "accounts.google.com" in self.driver.current_url:
                    # Preenche email
                    email_field = self.wait.until(EC.presence_of_element_located((By.ID, "identifierId")))
                    email_field.send_keys(email)
                    
                    # Clica em próximo
                    next_button = self.driver.find_element(By.ID, "identifierNext")
                    next_button.click()
                    
                    time.sleep(2)
                    
                    # Preenche senha
                    password_field = self.wait.until(EC.element_to_be_clickable((By.NAME, "password")))
                    password_field.send_keys(password)
                    
                    # Clica em próximo
                    password_next = self.driver.find_element(By.ID, "passwordNext")
                    password_next.click()
                    
                    time.sleep(5)  # Aguarda login completar
                
                duration = time.time() - start_time
                screenshot = self.take_screenshot("02_login_google")
                
                return {
                    'status': 'success',
                    'duration': duration,
                    'screenshot': screenshot,
                    'message': f'Login realizado com sucesso em {duration:.2f}s'
                }
            else:
                return {
                    'status': 'failed',
                    'duration': time.time() - start_time,
                    'screenshot': self.take_screenshot("02_login_google_error"),
                    'message': 'Botão de login não encontrado'
                }
                
        except Exception as e:
            return {
                'status': 'failed',
                'duration': time.time() - start_time,
                'screenshot': self.take_screenshot("02_login_google_error"),
                'message': f'Erro no login: {str(e)}'
            }
    
    def step_search_product(self, product_name):
        """Passo 3: Busca pelo produto"""
        try:
            start_time = time.time()
            
            # Procura por campo de busca
            search_selectors = [
                "input[type='search']",
                "input[placeholder*='buscar']",
                "input[placeholder*='Buscar']",
                "input[placeholder*='pesquisar']",
                "input[placeholder*='Pesquisar']",
                ".search-input",
                "#search-input",
                "#search",
                ".search"
            ]
            
            search_field = None
            for selector in search_selectors:
                try:
                    search_field = self.wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, selector)))
                    break
                except TimeoutException:
                    continue
            
            if search_field:
                search_field.clear()
                search_field.send_keys(product_name)
                
                # Procura por botão de busca
                search_button_selectors = [
                    "button[type='submit']",
                    ".search-button",
                    "#search-button",
                    "//button[contains(text(), 'Buscar')]",
                    "//button[contains(text(), 'Pesquisar')]"
                ]
                
                search_button = None
                for selector in search_button_selectors:
                    try:
                        if selector.startswith("//"):
                            search_button = self.driver.find_element(By.XPATH, selector)
                        else:
                            search_button = self.driver.find_element(By.CSS_SELECTOR, selector)
                        break
                    except NoSuchElementException:
                        continue
                
                if search_button:
                    search_button.click()
                else:
                    # Tenta pressionar Enter
                    from selenium.webdriver.common.keys import Keys
                    search_field.send_keys(Keys.RETURN)
                
                time.sleep(3)  # Aguarda resultados carregarem
                
                duration = time.time() - start_time
                screenshot = self.take_screenshot("03_search_product")
                
                return {
                    'status': 'success',
                    'duration': duration,
                    'screenshot': screenshot,
                    'message': f'Busca realizada com sucesso em {duration:.2f}s'
                }
            else:
                return {
                    'status': 'failed',
                    'duration': time.time() - start_time,
                    'screenshot': self.take_screenshot("03_search_product_error"),
                    'message': 'Campo de busca não encontrado'
                }
                
        except Exception as e:
            return {
                'status': 'failed',
                'duration': time.time() - start_time,
                'screenshot': self.take_screenshot("03_search_product_error"),
                'message': f'Erro na busca: {str(e)}'
            }
    
    def step_add_to_cart(self):
        """Passo 4: Adiciona produto ao carrinho"""
        try:
            start_time = time.time()
            
            # Procura pelo primeiro produto nos resultados
            product_selectors = [
                ".product-item",
                ".product",
                ".item",
                "[data-testid='product']",
                ".product-card"
            ]
            
            product = None
            for selector in product_selectors:
                try:
                    products = self.driver.find_elements(By.CSS_SELECTOR, selector)
                    if products:
                        product = products[0]
                        break
                except:
                    continue
            
            if product:
                # Clica no produto para ver detalhes
                product.click()
                time.sleep(2)
                
                # Procura por botão "Adicionar ao carrinho"
                add_to_cart_selectors = [
                    "//button[contains(text(), 'Adicionar')]",
                    "//button[contains(text(), 'Comprar')]",
                    "//a[contains(text(), 'Adicionar')]",
                    "//a[contains(text(), 'Comprar')]",
                    ".add-to-cart",
                    "#add-to-cart",
                    ".btn-buy",
                    ".buy-button"
                ]
                
                add_button = None
                for selector in add_to_cart_selectors:
                    try:
                        if selector.startswith("//"):
                            add_button = self.wait.until(EC.element_to_be_clickable((By.XPATH, selector)))
                        else:
                            add_button = self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, selector)))
                        break
                    except TimeoutException:
                        continue
                
                if add_button:
                    add_button.click()
                    time.sleep(3)  # Aguarda produto ser adicionado
                    
                    duration = time.time() - start_time
                    screenshot = self.take_screenshot("04_add_to_cart")
                    
                    return {
                        'status': 'success',
                        'duration': duration,
                        'screenshot': screenshot,
                        'message': f'Produto adicionado ao carrinho em {duration:.2f}s'
                    }
                else:
                    return {
                        'status': 'failed',
                        'duration': time.time() - start_time,
                        'screenshot': self.take_screenshot("04_add_to_cart_error"),
                        'message': 'Botão "Adicionar ao carrinho" não encontrado'
                    }
            else:
                return {
                    'status': 'failed',
                    'duration': time.time() - start_time,
                    'screenshot': self.take_screenshot("04_add_to_cart_error"),
                    'message': 'Nenhum produto encontrado nos resultados'
                }
                
        except Exception as e:
            return {
                'status': 'failed',
                'duration': time.time() - start_time,
                'screenshot': self.take_screenshot("04_add_to_cart_error"),
                'message': f'Erro ao adicionar ao carrinho: {str(e)}'
            }
    
    def step_go_to_cart(self):
        """Passo 5: Vai para o carrinho"""
        try:
            start_time = time.time()
            
            # Procura por link/botão do carrinho
            cart_selectors = [
                "//a[contains(text(), 'Carrinho')]",
                "//button[contains(text(), 'Carrinho')]",
                "//a[contains(@href, 'cart')]",
                "//a[contains(@href, 'carrinho')]",
                ".cart-link",
                "#cart-link",
                ".cart-button",
                "#cart-button"
            ]
            
            cart_element = None
            for selector in cart_selectors:
                try:
                    if selector.startswith("//"):
                        cart_element = self.wait.until(EC.element_to_be_clickable((By.XPATH, selector)))
                    else:
                        cart_element = self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, selector)))
                    break
                except TimeoutException:
                    continue
            
            if cart_element:
                cart_element.click()
                time.sleep(3)  # Aguarda carrinho carregar
                
                duration = time.time() - start_time
                screenshot = self.take_screenshot("05_go_to_cart")
                
                return {
                    'status': 'success',
                    'duration': duration,
                    'screenshot': screenshot,
                    'message': f'Carrinho acessado em {duration:.2f}s'
                }
            else:
                # Tenta navegar diretamente para URL do carrinho
                cart_url = "https://www.maiscorreios.com.br/checkout/#/cart"
                self.driver.get(cart_url)
                time.sleep(3)
                
                duration = time.time() - start_time
                screenshot = self.take_screenshot("05_go_to_cart")
                
                return {
                    'status': 'success',
                    'duration': duration,
                    'screenshot': screenshot,
                    'message': f'Carrinho acessado via URL direta em {duration:.2f}s'
                }
                
        except Exception as e:
            return {
                'status': 'failed',
                'duration': time.time() - start_time,
                'screenshot': self.take_screenshot("05_go_to_cart_error"),
                'message': f'Erro ao acessar carrinho: {str(e)}'
            }
    
    def step_checkout_process(self, address_data):
        """Passo 6: Processo de checkout"""
        try:
            start_time = time.time()
            
            # Procura por botão de finalizar compra/checkout
            checkout_selectors = [
                "//button[contains(text(), 'Finalizar')]",
                "//button[contains(text(), 'Checkout')]",
                "//a[contains(text(), 'Finalizar')]",
                "//a[contains(text(), 'Checkout')]",
                ".checkout-button",
                "#checkout-button",
                ".btn-checkout",
                ".finalize-button"
            ]
            
            checkout_button = None
            for selector in checkout_selectors:
                try:
                    if selector.startswith("//"):
                        checkout_button = self.wait.until(EC.element_to_be_clickable((By.XPATH, selector)))
                    else:
                        checkout_button = self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, selector)))
                    break
                except TimeoutException:
                    continue
            
            if checkout_button:
                checkout_button.click()
                time.sleep(3)
                
                # Tenta preencher dados de endereço se necessário
                try:
                    # CEP
                    cep_field = self.driver.find_element(By.CSS_SELECTOR, "input[name*='cep'], input[placeholder*='CEP'], #cep")
                    cep_field.clear()
                    cep_field.send_keys(address_data.get('cep', ''))
                    time.sleep(1)
                    
                    # Rua
                    street_field = self.driver.find_element(By.CSS_SELECTOR, "input[name*='rua'], input[name*='street'], input[placeholder*='Rua']")
                    street_field.clear()
                    street_field.send_keys(address_data.get('street', ''))
                    
                    # Número
                    number_field = self.driver.find_element(By.CSS_SELECTOR, "input[name*='numero'], input[name*='number'], input[placeholder*='Número']")
                    number_field.clear()
                    number_field.send_keys(address_data.get('number', ''))
                    
                except NoSuchElementException:
                    # Campos de endereço não encontrados, continua
                    pass
                
                duration = time.time() - start_time
                screenshot = self.take_screenshot("06_checkout_process")
                
                return {
                    'status': 'success',
                    'duration': duration,
                    'screenshot': screenshot,
                    'message': f'Processo de checkout iniciado em {duration:.2f}s'
                }
            else:
                # Tenta navegar diretamente para URL de pagamento
                payment_url = "https://www.maiscorreios.com.br/checkout/#/payment"
                self.driver.get(payment_url)
                time.sleep(3)
                
                duration = time.time() - start_time
                screenshot = self.take_screenshot("06_checkout_process")
                
                return {
                    'status': 'success',
                    'duration': duration,
                    'screenshot': screenshot,
                    'message': f'Checkout acessado via URL direta em {duration:.2f}s'
                }
                
        except Exception as e:
            return {
                'status': 'failed',
                'duration': time.time() - start_time,
                'screenshot': self.take_screenshot("06_checkout_process_error"),
                'message': f'Erro no checkout: {str(e)}'
            }
    
    def cleanup(self):
        """Limpa recursos"""
        try:
            if self.driver:
                self.driver.quit()
        except:
            pass
    
    def execute_full_test(self, config):
        """Executa o teste completo"""
        steps_results = []
        
        try:
            # Configurar driver
            if not self.setup_driver():
                return {
                    'status': 'failed',
                    'steps_results': [],
                    'error': 'Falha ao configurar driver do navegador'
                }
            
            # Passo 1: Acessar site
            result = self.step_access_site(config['site_url'])
            steps_results.append({
                'step_name': 'access_site',
                'step_order': 1,
                **result
            })
            
            if result['status'] != 'success':
                return {
                    'status': 'failed',
                    'steps_results': steps_results,
                    'error': 'Falha ao acessar o site'
                }
            
            # Passo 2: Login com Google
            result = self.step_login_google(config['email'], config['password'])
            steps_results.append({
                'step_name': 'login_google',
                'step_order': 2,
                **result
            })
            
            # Passo 3: Buscar produto
            result = self.step_search_product(config['product_name'])
            steps_results.append({
                'step_name': 'search_product',
                'step_order': 3,
                **result
            })
            
            # Passo 4: Adicionar ao carrinho
            result = self.step_add_to_cart()
            steps_results.append({
                'step_name': 'add_to_cart',
                'step_order': 4,
                **result
            })
            
            # Passo 5: Ir para carrinho
            result = self.step_go_to_cart()
            steps_results.append({
                'step_name': 'go_to_cart',
                'step_order': 5,
                **result
            })
            
            # Passo 6: Processo de checkout
            result = self.step_checkout_process(config['address'])
            steps_results.append({
                'step_name': 'checkout_process',
                'step_order': 6,
                **result
            })
            
            # Calcular resultado geral
            successful_steps = sum(1 for step in steps_results if step['status'] == 'success')
            total_steps = len(steps_results)
            success_rate = (successful_steps / total_steps) * 100
            
            overall_status = 'success' if successful_steps == total_steps else 'partial' if successful_steps > 0 else 'failed'
            
            return {
                'status': overall_status,
                'steps_results': steps_results,
                'steps_completed': successful_steps,
                'total_steps': total_steps,
                'success_rate': success_rate
            }
            
        except Exception as e:
            return {
                'status': 'failed',
                'steps_results': steps_results,
                'error': f'Erro durante execução do teste: {str(e)}'
            }
        finally:
            self.cleanup()

